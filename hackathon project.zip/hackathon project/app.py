from flask import Flask, render_template, request, jsonify
import pandas as pd

app = Flask(__name__)

# Load the customer service dataset
try:
    df = pd.read_csv('customerService.csv')
except FileNotFoundError:
    df = pd.DataFrame(columns=['customer_id', 'feedback'])
    print("Warning: customerService.csv not found. Using empty DataFrame.")
except Exception as e:
    df = pd.DataFrame(columns=['customer_id', 'feedback'])
    print(f"Error loading customerService.csv: {e}")

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/get_response', methods=['POST'])
def get_response():
    user_message = request.form['message']
    try:
        customer_id = int(user_message)

        feedback = df[df['customer_id'] == customer_id]['feedback']

        if not feedback.empty:
            response = feedback.values[0]
        else:
            response = "No feedback found for this customer ID."

    except ValueError:
        response = "Invalid input format. Please enter a numeric ID."
    except Exception as e:
        response = f"An error occurred: {e}"

    return jsonify({"response": response})

if __name__ == '__main__':
    app.run(debug=True)
